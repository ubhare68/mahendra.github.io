<?php
    global $VISUAL_COMPOSER_EXTENSIONS;
	
	// Currently no Elements for Other Demo Shortcodes
?>